import inference


if __name__ == "__main__":
        dist = inference.DiscreteDistribution()
        dist['a'] = 2
        dist['b'] = 8
        dist['c'] = 10
        print(dist)
        sum=dist.total()
        newDict=inference.DiscreteDistribution()
        temp=0
        for item in dist:
            newDict[item]=temp+dist[item]
            temp=newDict[item]
        print(newDict)
        N = 10000.0
        samples = [dist.sample() for _ in range(int(N))]
        
        print(samples.count('a'))
        print(samples.count('b'))
        print(samples.count('c'))
        print(round(samples.count('a') * 1.0/N, 1))
        
        print(round(samples.count('b') * 1.0/N, 1))
        
        print(round(samples.count('c') * 1.0/N, 1))
        
        
        

