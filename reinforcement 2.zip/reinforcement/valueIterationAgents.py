# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import mdp, util

from learningAgents import ValueEstimationAgent
import collections

class ValueIterationAgent(ValueEstimationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A ValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100):
        """
          Your value iteration agent should take an mdp on
          construction, run the indicated number of iterations
          and then act according to the resulting policy.

          Some useful mdp methods you will use:
              mdp.getStates()
              mdp.getPossibleActions(state)
              mdp.getTransitionStatesAndProbs(state, action)
                  Returns list of (nextState, prob) pairs
                  representing the states reachable
                  from 'state' by taking 'action' along
                  with their transition probabilities.
        
              mdp.getReward(state, action, nextState)
              mdp.isTerminal(state)
        """
        self.mdp = mdp
        self.discount = discount
        self.iterations = iterations
        self.values = util.Counter() # A Counter is a dict with default 0
        self.runValueIteration()

    def runValueIteration(self):
        # Write value iteration code here
        "*** YOUR CODE HERE ***"
        
        
        states=self.mdp.getStates()
        #for state in states:
            #self.values[state]=0
        
        for k in range(self.iterations):
            nextValues=util.Counter()
            
            for state in states:
                
                actions=self.mdp.getPossibleActions(state)
                qValues=util.Counter()
                for action in actions:
                
                    qValues[action]=self.computeQValueFromValues(state, action)
                    
                
                bestAction=qValues.argMax()
                bestQ=qValues[bestAction]
                nextValues[state]=bestQ
            
            self.values=nextValues
            
    def getValue(self, state):
        """
          Return the value of the state (computed in __init__).
        """
        return self.values[state]


    def computeQValueFromValues(self, state, action):
        """
          Compute the Q-value of action in state from the
          value function stored in self.values.
        """
        "*** YOUR CODE HERE ***"
        successors=self.mdp.getTransitionStatesAndProbs(state, action)

        qValue=0
        for successor in successors:
            nextState=successor[0]
            nextProb=successor[1]

            qValue=qValue+nextProb*(self.mdp.getReward(state, action, nextState)+self.discount*self.values[nextState])
        
        return qValue
        util.raiseNotDefined()

    def computeActionFromValues(self, state):
        """
          The policy is the best action in the given state
          according to the values currently stored in self.values.

          You may break ties any way you see fit.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return None.
        """
        "*** YOUR CODE HERE ***"
        actions=self.mdp.getPossibleActions(state)
        qValues=util.Counter()
        for action in actions:
            qValues[action]=self.computeQValueFromValues(state, action)
        
        bestAction=qValues.argMax()
		
        return bestAction
        
        util.raiseNotDefined()

    def getPolicy(self, state):
        return self.computeActionFromValues(state)

    def getAction(self, state):
        "Returns the policy at the state (no exploration)."
        return self.computeActionFromValues(state)

    def getQValue(self, state, action):
        return self.computeQValueFromValues(state, action)

class AsynchronousValueIterationAgent(ValueIterationAgent):
    """
        * Please read learningAgents.py before reading this.*

        An AsynchronousValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs cyclic value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 1000):
        """
          Your cyclic value iteration agent should take an mdp on
          construction, run the indicated number of iterations,
          and then act according to the resulting policy. Each iteration
          updates the value of only one state, which cycles through
          the states list. If the chosen state is terminal, nothing
          happens in that iteration.

          Some useful mdp methods you will use:
              mdp.getStates()
              mdp.getPossibleActions(state)
              mdp.getTransitionStatesAndProbs(state, action)
              mdp.getReward(state)
              mdp.isTerminal(state)
        """
        ValueIterationAgent.__init__(self, mdp, discount, iterations)

    def runValueIteration(self):
        "*** YOUR CODE HERE ***"
        
        states=self.mdp.getStates()
        #for state in states:
            #self.values[state]=0
        
        for k in range(self.iterations):
            
            
            state=states[k%len(states)]
                
            actions=self.mdp.getPossibleActions(state)
            qValues=util.Counter()
            for action in actions:
                
                qValues[action]=self.computeQValueFromValues(state, action)
                    
                
            bestAction=qValues.argMax()
            bestQ=qValues[bestAction]
            self.values[state]=bestQ
            
            

class PrioritizedSweepingValueIterationAgent(AsynchronousValueIterationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A PrioritizedSweepingValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs prioritized sweeping value iteration
        for a given number of iterations using the supplied parameters.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100, theta = 1e-5):
        """
          Your prioritized sweeping value iteration agent should take an mdp on
          construction, run the indicated number of iterations,
          and then act according to the resulting policy.
        """
        self.theta = theta
        ValueIterationAgent.__init__(self, mdp, discount, iterations)

    def runValueIteration(self):
        "*** YOUR CODE HERE ***"
        states=self.mdp.getStates()
        
        #Initialize an empty priority queue.
        pQueue=util.PriorityQueue()

        #Compute predecessors of all states.
        pOs=util.Counter()
        for state in states:
            currP=set()
            for pState in states:
                if self.mdp.isTerminal(pState) or (pState in currP):
                    continue
                    
                actions=self.mdp.getPossibleActions(pState)
                
                for action in actions:
                    successors=self.mdp.getTransitionStatesAndProbs(pState, action)
                    for successor in successors:
                        if successor[0]==state:
                            currP.add(pState)
            pOs[state]=currP
            
        for state in states:
            if not self.mdp.isTerminal(state):
                actions=self.mdp.getPossibleActions(state)
                qValues=util.Counter()
                for action in actions:
                    qValues[action]=self.computeQValueFromValues(state, action)
                bestAction=qValues.argMax()
                bestQ=qValues[bestAction]
                
                diff=abs(bestQ-self.values[state])
                pQueue.push(state,-1.0*diff)
                
 
        for k in range(self.iterations):
            if pQueue.isEmpty():
                break
            else:
                state=pQueue.pop()
                
                if not self.mdp.isTerminal(state):
                    actions=self.mdp.getPossibleActions(state)
                    qValues=util.Counter()
                    for action in actions:
                        qValues[action]=self.computeQValueFromValues(state, action)
                    bestAction=qValues.argMax()
                    bestQ=qValues[bestAction]
                    self.values[state]=bestQ
                curPs=pOs[state]
                for p in curPs:
                    actions=self.mdp.getPossibleActions(p)
                    qValues=util.Counter()
                    for action in actions:
                        qValues[action]=self.computeQValueFromValues(p, action)
                    bestAction=qValues.argMax()
                    bestQ=qValues[bestAction]
                
                    diff=abs(bestQ-self.values[p])
                    if diff>self.theta:
                        pQueue.update(p,-1.0*diff)